﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Northwind_Asp.Models;

namespace Northwind_Asp.Controllers
{
    public class CategoryController : Controller
    {
        // GET: Category
        public ActionResult Index()
        {
            CategoryGateway aCategoryGateway = new CategoryGateway();
            List<Category> aCategoryList = aCategoryGateway.GetCategories();

            ViewBag.Categories = aCategoryList;
            return View();
        }

        public ActionResult ProductsPerCategory(string ID)
        {
            CategoryGateway aCategoryGateway = new CategoryGateway();
            ProductGateway aProductGateway = new ProductGateway();
            List<Product> productsList = aProductGateway.GetProductsByCategory(ID);
            List<Category> categoryList = aCategoryGateway.GetCategoriesByID(ID);
            var productList = from c in productsList
                              orderby c.ProductName ascending
                              select c;

            ViewBag.Products = productList;
            ViewBag.Categories = categoryList[0];

            return View();
        }
    }
}