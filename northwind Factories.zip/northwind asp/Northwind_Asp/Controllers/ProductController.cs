﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Northwind_Asp.Models;

namespace Northwind_Asp.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult BrowseAll()
        {
            ProductGateway aProductGateway = new ProductGateway();
            // OleDbUtilityLoader aConnection = new OleDbUtilityLoader();
            List<Product> aProductList = aProductGateway.GetProducts();
            var products = from p in aProductList
                           orderby p.ProductName ascending
                           select p;
            ViewBag.Products = products;
            return View();
        }
        public ActionResult Details(String ID)
        {
            ProductGateway aProductGateway = new ProductGateway();
            List<Product> aProductList = aProductGateway. GetProductByID(ID);

            ViewBag.Products = aProductList[0];
            return View();
        }

        public ActionResult SearchProducts()
        {
            return View();   
        }

        public ActionResult BrowseByPrice(int min, int max)
        {
            ProductGateway aProductGateway = new ProductGateway();
            List<Product> productsList = aProductGateway.GetProductsByUnitPrice(min, max);
            var costProducts = from c in productsList
                              orderby c.UnitPrice ascending
                              select c;
            ViewBag.Products = costProducts;
            
            return View();
        }
    }
}