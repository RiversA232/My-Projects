﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Northwind_Asp.Models;

namespace Northwind_Asp.Controllers
{
    public class SupplierController : Controller
    {
        // GET: Supplier
        public ActionResult Index()
        {
            SupplierGateway aSupplierGateway = new SupplierGateway();
            List<Supplier> aSupplierList = aSupplierGateway.GetSuppliers();

            ViewBag.Suppliers = aSupplierList;
            return View();
        }

        public ActionResult ProductsPerSupplier(string ID)
        {
            SupplierGateway aSupplierGateway = new SupplierGateway();
            ProductGateway aProductGateway = new ProductGateway();
            List<Product> aListOfProducts = aProductGateway.GetProductsBySupplier(ID);
            List<Supplier> aListOfSuppliers = aSupplierGateway.GetSuppliersById(ID);
            var productList = from c in aListOfProducts
                              orderby c.ProductName ascending
                              select c;

            ViewBag.Products = productList;
            ViewBag.Suppliers = aListOfSuppliers[0];

            return View();
        }

        public ActionResult Details(string ID)
        {
            ProductGateway aProductGateway = new ProductGateway();

            ViewBag.Categories = aProductGateway.GetProductsByCategory(ID)[0];
            return View();
        }
    }
}