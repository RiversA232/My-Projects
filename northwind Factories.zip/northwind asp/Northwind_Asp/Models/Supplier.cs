﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public class Supplier
    {
        //Create Class Members
        public static int numSuppliers = 0;
        private int supplierID = -9;
        private string companyName = "N/A";
        private string contactName = "N/A";
        private string contactTitle = "N/A";
        private string address = "N/A";
        private string city = "N/A";
        private string region = "N/A";
        private string postalCode = "N/A";
        private string country = "N/A";
        private string phone = "N/A";
        private string fax = "N/A";
        private string homePage = "N/A";
        private bool isDirty = false;
        private BrokenRules aBrokenRules = new BrokenRules();
        public static string totalCount()
        {
            return "Suppliers: " + numSuppliers + "\n";
        }
        //static counter
        public Supplier()
        {
            numSuppliers++;
        }
        //start of constructors
        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion, string aPostalCode, string aCountry, string aPhone, string aFax, string aHomePage)
            : this()
        {
            this.supplierID = aSupplierID;
            this.CompanyName = aCompanyName;
            this.ContactName = aContactName;
            this.ContactTitle = aContactTitle;
            this.Address = anAddress;
            this.City = aCity;
            this.Region = aRegion;
            this.PostalCode = aPostalCode;
            this.Country = aCountry;
            this.Phone = aPhone;
            this.Fax = aFax;
            this.HomePage = aHomePage;
        }
        //constructors
        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion, string aPostalCode, string aCountry, string aPhone, string aFax)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, aFax, "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion, string aPostalCode, string aCountry, string aPhone)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion, string aPostalCode, string aCountry)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, aCountry, "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion, string aPostalCode)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity, string aRegion)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress, string aCity)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string anAddress)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle)
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName)
            : this(aSupplierID, aCompanyName, aContactName, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID, string aCompanyName)
            : this(aSupplierID, aCompanyName, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }

        public Supplier(int aSupplierID)
            : this(aSupplierID, "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A")
        {
        }
        //Get/Sets
        public int SupplierID
        {
            get
            {
                return supplierID;
            }
        }

        public string CompanyName
        {
            get
            {
                return companyName;
            }
            set
            {
                this.companyName = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "CompanyNameRequired";
                aRule.RuleDescription = "You must supply a non empty CompanyName";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string ContactName
        {
            get
            {
                return contactName;
            }
            set
            {
                this.contactName = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "ContactNameRequired";
                aRule.RuleDescription = "You must supply a non empty Contact Name";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string ContactTitle
        {
            get
            {
                return contactTitle;
            }
            set
            {
                this.contactTitle = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "CompanyTitleRequired";
                aRule.RuleDescription = "You must supply a non empty Contact Title";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                this.address = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "AddressRequired";
                aRule.RuleDescription = "You must supply a non empty Address";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string City
        {
            get
            {
                return city;
            }
            set
            {
                this.city = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "CityRequired";
                aRule.RuleDescription = "You must supply a non empty City";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string Region
        {
            get
            {
                return region;
            }
            set
            {
                this.region = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "RegionRequired";
                aRule.RuleDescription = "You must supply a non empty Region";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string PostalCode
        {
            get
            {
                return postalCode;
            }
            set
            {
                this.postalCode = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "PostalCodeRequired";
                aRule.RuleDescription = "You must supply a non empty Postal Code";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string Country
        {
            get
            {
                return country;
            }
            set
            {
                this.country = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "CountryRequired";
                aRule.RuleDescription = "You must supply a non empty Country";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string Phone
        {
            get
            {
                return phone;
            }
            set
            {
                this.phone = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "PhoneRequired";
                aRule.RuleDescription = "You must supply a non empty Phone";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string Fax
        {
            get
            {
                return fax;
            }
            set
            {
                this.fax = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "FaxRequired";
                aRule.RuleDescription = "You must supply a non empty fax";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }

        public string HomePage
        {
            get
            {
                return homePage;
            }
            set
            {
                this.homePage = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "HomePageRequired";
                aRule.RuleDescription = "You must supply a non empty Home Page";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }
        public bool IsDirty
        {
            get
            {
                return isDirty;
            }
            set
            {
                isDirty = value;
            }
        }

        public bool isValid
        {
            get
            {
                if (aBrokenRules.GetDictionary().Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        //ToString Method
        public override string ToString()
        {
            string output = "";
            output += "Supplier ID: " + SupplierID + "<br />";
            output += "Company Name: " + CompanyName + "<br />";
            output += "Contact Name: " + ContactName + "<br />";
            output += "Contact Title: " + ContactTitle + "<br />";
            output += "Address: " + Address + "<br />";
            output += "City: " + City + "<br />";
            output += "Region: " + Region + "<br />";
            output += "PostalCode: " + PostalCode + "<br />";
            output += "Country: " + Country + "<br />";
            output += "Phone: " + Phone + "<br />";
            output += "Fax: " + Fax + "<br />";
            output += "Home Page: " + HomePage + "<br />";

            return output;
        }
    }
}
