﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class DBConnection
    {
        //Connection string contains path to database
        public static string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

        //Connection object
        public static OleDbConnection aConnection = new OleDbConnection(connectionString);

        //Command object
        public OleDbCommand aCommand = aConnection.CreateCommand();

        public List<Category> GetCategories()
        {
            List<Category> categoryList = new List<Category>();

            //attempt to open database connection
            aConnection.Open();

            //If connection is open- set query to be run, instatiate reader object
            if (aConnection.State == System.Data.ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories;";
                OleDbDataReader aReader = aCommand.ExecuteReader();

                //while reader is active, create object using data from DB and add object to list
                while (aReader.Read())
                {
                    int anID = aReader["CategoryID"] as int? ?? -1;
                    string aCategoryName = aReader["CategoryName"] as string ?? String.Empty;
                    string aDescription = aReader["Description"] as string ?? String.Empty;

                    Category aCategory = new Category(anID, aCategoryName, aDescription);
                    categoryList.Add(aCategory);
                }
            }
            //Close connection and return list
            aConnection.Close();
            return categoryList;
        }

        public List<Category> GetCategoriesByID(String ID)
        {
            List<Category> categoryList = new List<Category>();

            //attempt to open database connection
            aConnection.Open();

            //If connection is open- set query to be run, instatiate reader object
            if (aConnection.State == System.Data.ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories WHERE CategoryID = " + ID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                //while reader is active, create object using data from DB and add object to list
                while (aReader.Read())
                {
                    int anID = aReader["CategoryID"] as int? ?? -1;
                    string aCategoryName = aReader["CategoryName"] as string ?? String.Empty;
                    string aDescription = aReader["Description"] as string ?? String.Empty;

                    Category aCategory = new Category(anID, aCategoryName, aDescription);
                    categoryList.Add(aCategory);
                }
            }
            //Close connection and return list
            aConnection.Close();
            return categoryList;
        }

        public List<Product> GetProducts()
        {
            List<Product> productList = new List<Product>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products";
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);

                    productList.Add(aProduct);
                }
            }
            aConnection.Close();
            return productList;
        }

        public List<Product> GetProductByID(string anID)
        {
            List<Product> aList = new List<Product>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE ProductID = " + anID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                    aList.Add(aProduct);
                }
            }
            aConnection.Close();
            return aList;
        }

        public List<Product> GetProductsByCategory(string anID)
        {
            List<Product> aList = new List<Product>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE CategoryID = " + anID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                    aList.Add(aProduct);
                }
            }
            aConnection.Close();
            return aList;
        }

        public List<Product> GetProductsBySupplier(string anID)
        {
            List<Product> aList = new List<Product>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE SupplierID = " + anID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                    aList.Add(aProduct);
                }
            }
            aConnection.Close();
            return aList;
        }

        public List<Product> GetProductsByPrice(double min, double max)
        {
            List<Product> aList = new List<Product>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE UnitPrice BETWEEN " + min + " AND " + max; ;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                    aList.Add(aProduct);
                }
            }
            aConnection.Close();
            return aList;
        }

        public List<Supplier> GetSuppliers()
        {
            List<Supplier> supplierList = new List<Supplier>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT SupplierID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage FROM Suppliers";
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aSupplierID = (int)aReader["SupplierID"];
                    string aCompanyName = (string)aReader["CompanyName"];
                    string aContactName = (string)aReader["ContactName"];
                    string aContactTitle = (string)aReader["ContactTitle"];
                    string anAddress = (string)aReader["Address"];
                    string aCity = (string)aReader["City"];
                    string aRegion = aReader["Region"] as string ?? String.Empty;
                    string aPostalCode = aReader["PostalCode"] as string ?? String.Empty;
                    string aCountry = (string)aReader["Country"];
                    string aPhone = (string)aReader["Phone"];
                    string aFax = aReader["Fax"] as string ?? String.Empty;
                    string aHomePage = aReader["HomePage"] as string ?? String.Empty;

                    Supplier aSupplier = new Supplier(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, aFax, aHomePage);
                    supplierList.Add(aSupplier);
                }
            }
            aConnection.Close();
            return supplierList;
        }

        public List<Supplier> GetSupplierByID(string ID)
        {
            List<Supplier> supplierList = new List<Supplier>();

            aConnection.Open();

            if (aConnection.State == ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT SupplierID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage FROM Suppliers WHERE SupplierID = " + ID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aSupplierID = (int)aReader["SupplierID"];
                    string aCompanyName = (string)aReader["CompanyName"];
                    string aContactName = (string)aReader["ContactName"];
                    string aContactTitle = (string)aReader["ContactTitle"];
                    string anAddress = (string)aReader["Address"];
                    string aCity = (string)aReader["City"];
                    string aRegion = aReader["Region"] as string ?? String.Empty;
                    string aPostalCode = aReader["PostalCode"] as string ?? String.Empty;
                    string aCountry = (string)aReader["Country"];
                    string aPhone = (string)aReader["Phone"];
                    string aFax = aReader["Fax"] as string ?? String.Empty;
                    string aHomePage = aReader["HomePage"] as string ?? String.Empty;

                    Supplier aSupplier = new Supplier(aSupplierID, aCompanyName, aContactName, aContactTitle, anAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, aFax, aHomePage);
                    supplierList.Add(aSupplier);
                }
            }
            aConnection.Close();
            return supplierList;
        }
    }
}