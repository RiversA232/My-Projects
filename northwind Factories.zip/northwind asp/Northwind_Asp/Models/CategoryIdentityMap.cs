﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Northwind_Asp.Models
{
    public class CategoryIdentityMap
    {
        private Dictionary<int, Category> aCategoryDictionary = new Dictionary<int, Category>();
        public Dictionary<int, Category> GetCategoryDictionary()
        {
            return aCategoryDictionary;
        }
        public Boolean isInCategoryDictionary(int aKey)
        {
            bool answer = false;
            answer = aCategoryDictionary.ContainsKey(aKey);
            return answer;
        }
        public void AddCategory(int aKey, Category aCategory)
        {
            aCategoryDictionary.Add(aKey, aCategory);
            //alternatively
            //aDictionary.Add(aCategory.CategoryId, aCategory);
        }
        public Category GetCategory(int aKey)
        {
            return aCategoryDictionary[aKey];
        }
        //you may at some point need to remove an item from the map.
        //Doesn't delete from the database.
        //All database functions are on the table gateway object.
        public void RemoveCategory(int aKey)
        {
            aCategoryDictionary.Remove(aKey);
        }
    }
}