﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class NWOdbcFactory : NWAbstractFactory
    {

        private NWOdbcDataReader aNWReader = new NWOdbcDataReader();
        private NWOdbcDataSet aNWDataSet = new NWOdbcDataSet();

        public override INWDataReader CreateReader(string aSQL)
        {
            // create the connection object
            OdbcConnection aConnection = new OdbcConnection();

            // set the connection string
            aConnection.ConnectionString = @"Driver={Microsoft Access Driver (*.mdb)};
                     DBQ=C:\Users\aaron\Downloads\Northwind.mdb;";

            // open the connection
            aConnection.Open();

            // create a command object
            OdbcCommand aCommand = aConnection.CreateCommand();

            // run the SQL statement
            aCommand.CommandText = aSQL;
            OdbcDataReader aReader = aCommand.ExecuteReader();


            aNWReader.aDataReader = aReader;

            return aNWReader;
        }

        public override INWDataSet CreateDataSet(string aSQL)
        {
            // create the connection object
            OdbcConnection aConnection = new OdbcConnection();

            // set the connection string
            aConnection.ConnectionString = @"Driver={Microsoft Access Driver (*.mdb)};
                     DBQ=C:\Users\aaron\Downloads\Northwind.mdb;";

            // open the connection
            aConnection.Open();

            // create a command object
            OdbcCommand aCommand = aConnection.CreateCommand();
            aCommand.CommandText = aSQL;

            // run the SQL statement
            OdbcDataAdapter anAdapter = new OdbcDataAdapter(aCommand);
            anAdapter.Fill(aNWDataSet.aDataSet);

            return aNWDataSet;
        }
    }
}