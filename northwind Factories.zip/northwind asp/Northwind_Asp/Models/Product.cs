﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public class Product
    {
        //Create Class Members 
        public static int numProducts = 0;
        private int productID = -1;
        private string productName = "N/A";
        private int supplierID = -1;
        private int categoryID = -1;
        private string quantityPerUnit = "N/A";
        private double unitPrice = 9999999.99;
        private int unitsInStock = 0;
        private int unitsOnOrder = 0;
        private int reorderLevel = 0;
        private bool discontinued = true;
        private bool isDirty = false;
        private BrokenRules aBrokenRules = new BrokenRules();
        public static string totalCount()
        {
            return "Products: " + numProducts + "<br />";
        }
        //Constructors Start Here
        public Product()
        {
            //initialization goes here
            numProducts++;
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit, double aUnitPrice, int aNumInStock, int aNumOnOrder, int aReorderLevel, bool isDiscontinued)
            : this()
        {
            this.productID = aProductID; //read-only field
            this.ProductName = aProductName;
            this.supplierID = aSupplierID; //read-only field
            this.categoryID = aCategoryID; //read-only field
            this.QuantityPerUnit = aQuantityPerUnit;
            this.UnitPrice = aUnitPrice;
            this.UnitsInStock = aNumInStock;
            this.UnitsOnOrder = aNumOnOrder;
            this.ReorderLevel = aReorderLevel;
            this.Discontinued = isDiscontinued;
        }
        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit, double aUnitPrice, int aNumInStock, int aNumOnOrder, int aReorderLevel)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aNumInStock, aNumOnOrder, aReorderLevel, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit, double aUnitPrice, int aNumInStock, int aNumOnOrder)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aNumInStock, aNumOnOrder, 0, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit, double aUnitPrice, int aNumInStock)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aNumInStock, 0, 0, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit, double aUnitPrice)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, 0, 0, 0, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID, string aQuantityPerUnit)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, 9999999.99, 0, 0, 0, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID, int aCategoryID)
            : this(aProductID, aProductName, aSupplierID, aCategoryID, "N/A", 9999999.99, 0, 0, 0, true)
        {
        }

        public Product(int aProductID, string aProductName, int aSupplierID)
            : this(aProductID, aProductName, aSupplierID, -1, "N/A", 9999999.99, 0, 0, 0, true)
        {
        }

        public Product(int aProductID, string aProductName)
            : this(aProductID, aProductName, -1, -1, "N/A", 9999999.99, 0, 0, 0, true)
        {
        }

        public Product(int aProductID)
            : this(aProductID, "N/A", -1, -1, "N/A", 9999999.99, 0, 0, 0, true)
        {
        }

        //Get/Set Methods
        public string ProductName
        {
            get
            {
                return this.productName;
            }
            set
            {
                this.productName = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "NameRequired";
                aRule.RuleDescription = "You must supply a non empty Product";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }
        public string QuantityPerUnit
        {
            get
            {
                return this.quantityPerUnit;
            }
            set
            {
                this.quantityPerUnit = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "QuantityPerUnitRequired";
                aRule.RuleDescription = "You must supply a non empty Quaninty Per Unit";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }
        public int ProductID
        {
            get
            {
                return this.productID;
            }
        }
        public int SupplierID
        {
            get
            {
                return this.supplierID;
            }
        }
        public int CategoryID
        {
            get
            {
                return this.categoryID;
            }
        }
        public int UnitsInStock
        {
            get
            {
                return this.unitsInStock;
            }
            set
            {
                this.unitsInStock = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "UnitsInStockRequired";
                aRule.RuleDescription = "You must supply a non empty Units in Stock";
            }
        }
        public int UnitsOnOrder
        {
            get
            {
                return this.unitsOnOrder;
            }
            set
            {
                this.unitsOnOrder = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "UnitsOnOrder";
                aRule.RuleDescription = "You must supply a non empty Units on Order";
            }
        }
        public int ReorderLevel
        {
            get
            {
                return this.reorderLevel;
            }
            set
            {
                this.reorderLevel = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "ReorderLevelRequired";
                aRule.RuleDescription = "You must supply a non empty Reorder Level";
            }
        }
        public double UnitPrice
        {
            get
            {
                return this.unitPrice;
            }
            set
            {
                isDirty = true;
                this.unitPrice = value;
                BrokenRule aRule = new BrokenRule();
                aRule.RuleName = "Negative Price";
                aRule.RuleDescription = "The Price is not negative";
                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value < 0));
            }
        }
        public bool IsDirty
        {
            get
            {
                return isDirty;
            }
            set
            {
                isDirty = value;
            }
        }

        public bool isValid
        {
            get
            {
                if (aBrokenRules.GetDictionary().Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public bool Discontinued
        {
            get
            {
                return this.discontinued;
            }
            set
            {
                this.discontinued = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule
                aRule.RuleName = "DiscontinuedRequired";
                aRule.RuleDescription = "You must supply a non empty discontinued value";
            }
        }
        public override string ToString()
        {
            // This method is for printing out the current state of the object
            string aString = "";
            aString = aString + "Product Name = " + ProductName + "<br />";
            aString = aString + "Quantity Per Unit = " + QuantityPerUnit + "<br />";
            aString = aString + "Product ID = " + ProductID + "<br />";
            aString = aString + "Supplier ID = " + SupplierID + "<br />";
            aString = aString + "Category Id = " + CategoryID + "<br />";
            aString = aString + "Units In Stock = " + UnitsInStock + "<br />";
            aString = aString + "Units On Order = " + UnitsOnOrder + "<br />";
            aString = aString + "Re-Order Level = " + ReorderLevel + "<br />";
            aString = aString + "UnitPrice = " + UnitPrice + "<br />";
            aString = aString + "Discontinued = " + Discontinued + "<br />";

            return aString;
        }
    }
}
