﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public class ProductIdentityMap
    {
        private Dictionary<int, Product> aProductDictionary = new Dictionary<int, Product>();
        public Dictionary<int, Product> GetProductDictionary()
        {
            return aProductDictionary;
        }
        public Boolean isInProductDictionary(int aKey)
        {
            bool answer = false;
            answer = aProductDictionary.ContainsKey(aKey);
            return answer;
        }
        public void AddProduct(int aKey, Product aCategory)
        {
            aProductDictionary.Add(aKey, aCategory);
            //alternatively
            //aDictionary.Add(aCategory.CategoryId, aCategory);
        }
        public Product GetProduct(int aKey)
        {
            return aProductDictionary[aKey];
        }
        //you may at some point need to remove an item from the map.
        //Doesn't delete from the database.
        //All database functions are on the table gateway object.
        public void RemoveProduct(int aKey)
        {
            aProductDictionary.Remove(aKey);
        }
    }
}