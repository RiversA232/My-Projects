﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class CategoryGateway
    {
        private CategoryIdentityMap aMap = new CategoryIdentityMap();
        //Connection string contains path to database
        public static string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

        //Connection object
        public static OleDbConnection aConnection = new OleDbConnection(connectionString);

        //Command object
        public OleDbCommand aCommand = aConnection.CreateCommand();

        public List<Category> GetCategories()
        {
            List<Category> categoryList = new List<Category>();

            //attempt to open database connection
            aConnection.Open();

            //If connection is open- set query to be run, instatiate reader object
            if (aConnection.State == System.Data.ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories;";
                OleDbDataReader aReader = aCommand.ExecuteReader();

                //while reader is active, create object using data from DB and add object to list
                while (aReader.Read())
                {
                    int anID = aReader["CategoryID"] as int? ?? -1;
                    string aCategoryName = aReader["CategoryName"] as string ?? String.Empty;
                    string aDescription = aReader["Description"] as string ?? String.Empty;

                    Category aCategory = new Category(anID, aCategoryName, aDescription);
                    categoryList.Add(aCategory);
                }
            }
            //Close connection and return list
            aConnection.Close();
            return categoryList;
        }

        public List<Category> GetCategoriesByID(String ID)
        {
            List<Category> categoryList = new List<Category>();

            //attempt to open database connection
            aConnection.Open();

            //If connection is open- set query to be run, instatiate reader object
            if (aConnection.State == System.Data.ConnectionState.Open)
            {
                aCommand.CommandText = "SELECT CategoryID, CategoryName, Description FROM Categories WHERE CategoryID = " + ID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                //while reader is active, create object using data from DB and add object to list
                while (aReader.Read())
                {
                    int anID = aReader["CategoryID"] as int? ?? -1;
                    string aCategoryName = aReader["CategoryName"] as string ?? String.Empty;
                    string aDescription = aReader["Description"] as string ?? String.Empty;

                    Category aCategory = new Category(anID, aCategoryName, aDescription);
                    categoryList.Add(aCategory);
                }
            }
            //Close connection and return list
            aConnection.Close();
            return categoryList;
        }
        public void SaveAllCategories()
        {
            Dictionary<int, Category> dictionary = aMap.GetCategoryDictionary();
            // create the connection object
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
            Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();

            // create a command object
            OleDbCommand aCommand = aConnection.CreateCommand();

            // Set the SQL statement
            string aSQL = "SELECT CategoryId, CategoryName, Description FROM Categories";

            aCommand.CommandText = aSQL;
            // run the SQL statement
            OleDbDataReader aReader = aCommand.ExecuteReader();

            foreach (var c in dictionary.Keys)
            {
                int aCategoryId = (int)aReader["CategoryId"];
                string aCategoryName = (string)aReader["CategoryName"];
                string aDescription = (string)aReader["Description"];
                if (dictionary[c].IsDirty == true && dictionary[c].IsValid == true)
                {
                    aSQL = aSQL + "SET CategoryName = " + "'" + aCategoryName + "',";
                    aSQL = aSQL + "Description = " + "'" + aDescription + "' ";
                    aSQL = aSQL + "WHERE CategoryId = " + "'" + aCategoryId;

                    aCommand.CommandText = aSQL;
                    aCommand.ExecuteNonQuery();
                }
            }
            aConnection.Close();
        }
    }
}