﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public interface INWList<T>
    {
        IList<T> aList
        {
            get;
            set;
        }
    }
}