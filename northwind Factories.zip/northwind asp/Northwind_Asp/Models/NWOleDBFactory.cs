﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Data.Sql;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class NWOleDBFactory : NWAbstractFactory
    {

        private NWOleDBDataReader aNWReader = new NWOleDBDataReader();
        private NWOleDBDataSet aNWDataSet = new NWOleDBDataSet();

        public override INWDataReader CreateReader(string aSQL)
        {
            // create the connection object
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
                    Data Source=C:\Users\aaron\Downloads\Northwind.mdb;";

            // open the connection
            aConnection.Open();

            // create a command object
            OleDbCommand aCommand = aConnection.CreateCommand();

            // run the SQL statement
            aCommand.CommandText = aSQL;
            OleDbDataReader aReader = aCommand.ExecuteReader();


            aNWReader.aDataReader = aReader;

            return aNWReader;
        }

        public override INWDataSet CreateDataSet(string aSQL)
        {
            // create the connection object
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
                    Data Source=C:\Users\aaron\Downloads\Northwind.mdb;";

            // open the connection
            aConnection.Open();

            // create a command object
            OleDbCommand aCommand = aConnection.CreateCommand();
            aCommand.CommandText = aSQL;

            // run the SQL statement
            OleDbDataAdapter anAdapter = new OleDbDataAdapter(aCommand);
            anAdapter.Fill(aNWDataSet.aDataSet);

            return aNWDataSet;
        }
    }
}