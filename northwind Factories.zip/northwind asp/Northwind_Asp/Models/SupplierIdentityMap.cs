﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public class SupplierIdentityMap
    {
        public Dictionary<int, Supplier> aSupplierDictionary = new Dictionary<int, Supplier>();
        public Dictionary<int, Supplier> GetSupplierDictionary()
        {
            return aSupplierDictionary;
        }
        public Boolean isInDictionary(int aKey)
        {
            bool answer = false;
            answer = aSupplierDictionary.ContainsKey(aKey);
            return answer;
        }
        public void AddSupplierCategory(int aKey, Supplier aCategory)
        {
            aSupplierDictionary.Add(aKey, aCategory);
            //alternatively
            //aDictionary.Add(aCategory.CategoryId, aCategory);
        }
        public Supplier GetSupplier(int aKey)
        {
            return aSupplierDictionary[aKey];
        }
        //you may at some point need to remove an item from the map.
        //Doesn't delete from the database.
        //All database functions are on the table gateway object.
        public void RemoveSupplier(int aKey)
        {
            aSupplierDictionary.Remove(aKey);
        }
    }
}