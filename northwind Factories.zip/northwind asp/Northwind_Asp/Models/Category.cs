﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind_Asp.Models
{
    public class Category
    {
        //Create Class Members
        public static int numCategories = 0;
        private int categoryID = 0;
        private string categoryName = "N/A";
        private string description = "N/A";
        private bool isDirty = false;
        private BrokenRules aBrokenRules = new BrokenRules();

        public static string totalCount()
        {
            return "Categories: " + numCategories + "\n";
        }

        //Constructors Start Here
        public Category()
        {

            //any initialization code would go here
            numCategories++;
        }
        // This is a constructer and only runs once when an object is first created
        public Category(int anID, string aCategoryName, string aDescription)
            : this()
        {
            this.categoryID = anID;
            this.categoryName = aCategoryName;
            this.description = aDescription;
        }
        public Category(int anID, string aCategoryName)
            : this(anID, aCategoryName, "N/A")
        {

        }
        public Category(int anID)
            : this(anID, "N/A", "N/A")
        {

        }

        //Get/Set Methods
        public int CategoryID
        {
            get
            {
                return this.categoryID;
            }
        }
        public string CategoryName
        {
            get
            {
                return this.categoryName;
            }
            set
            {
                this.categoryName = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule....Basically non trad. method.
                aRule.RuleName = "NameRequired";
                aRule.RuleDescription = "You must supply a non empty Category Name";
                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }
        public string Description
        {
            get
            {
                return this.description;
            }
            set
            {
                this.description = value;
                isDirty = true;
                BrokenRule aRule = new BrokenRule();
                // somewhere rules may already exist
                // this is, your organization may have standardized rules
                //we don have that, thus we have to make our broken rule...basically non trad-method.
                aRule.RuleName = "DescriptionRequired";
                aRule.RuleDescription = "You must supply a non empty Category Description";

                aBrokenRules.CheckRule(aRule.RuleName, aRule, !(value.Length > 0));
            }
        }
        public bool IsDirty
        {
            get 
            { 
                return isDirty; 
            }
            set 
            { 
                isDirty = value; 
            }
        }

        public bool IsValid
        {
            get
            {
                if (aBrokenRules.GetDictionary().Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public override string ToString()
        {
            // This method is for printing out the current state of the object
            string aString = "";
            aString = aString + "Category Id = " + CategoryID + "<br />";
            aString = aString + "Category Name = " + CategoryName + "<br />";
            aString = aString + "Description = " + Description + "<br />";
            return aString;
        }
    }
}

