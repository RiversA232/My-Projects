﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class ProductGateway
    {
        private ProductIdentityMap aMap = new ProductIdentityMap();

        public static string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";
        public static OleDbConnection aConnection = new OleDbConnection(connectionString);
        public OleDbCommand aCommand = aConnection.CreateCommand();

        //Gets a List of Products from a database
        public List<Product> GetProducts()
        {

            // open the connection
            aConnection.Open();
            List<Product> aProductList = new List<Product>();

            aCommand.CommandText = "SELECT ProductID,ProductName,SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products";
            OleDbDataReader aReader = aCommand.ExecuteReader();

            while (aReader.Read())
            {

                int aProductID = (int)aReader["ProductID"];
                string aProductName = (string)aReader["ProductName"];
                int aSupplierID = (int)aReader["SupplierID"];
                int aCategoryID = (int)aReader["CategoryID"];
                string aQuantityPerUnit = (string)aReader["QuantityPerUnit"];
                double aUnitPrice = (double)(decimal)aReader["UnitPrice"];
                int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                int aUnitsOnOrder = (short)aReader["UnitsOnOrder"];
                int aReorderLevel = (short)aReader["ReorderLevel"];
                bool isDiscontinued = (bool)aReader["Discontinued"];

                Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                aProductList.Add(aProduct);

            }
            aConnection.Close();
            return aProductList;

        }

        public List<Product> GetProductsByCategory(String theId)
        {
            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();
            List<Product> aProductList = new List<Product>();
            aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE CategoryID = " + theId;
            OleDbDataReader aReader = aCommand.ExecuteReader();

            while (aReader.Read())
            {

                int aProductID = (int)aReader["ProductID"];
                string aProductName = (string)aReader["ProductName"];
                int aSupplierID = (int)aReader["SupplierID"];
                int aCategoryID = (int)aReader["CategoryID"];
                string aQuantityPerUnit = (string)aReader["QuantityPerUnit"];
                double aUnitPrice = (double)(decimal)aReader["UnitPrice"];
                int aUnitsInStock = (short)aReader["UnitsInStock"];
                int aUnitsOnOrder = (short)aReader["UnitsOnOrder"];
                int aReorderLevel = (short)aReader["ReorderLevel"];
                bool isDiscontinued = (bool)aReader["Discontinued"];

                Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                aProductList.Add(aProduct);

            }
            aConnection.Close();
            return aProductList;

        }
        public List<Product> GetProductsBySupplier(String theId)
        {

            // open the connection
            aConnection.Open();
            List<Product> aProductList = new List<Product>();

            aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE SupplierId = " + theId;
            OleDbDataReader aReader = aCommand.ExecuteReader();

            while (aReader.Read())
            {

                int aProductID = (int)aReader["ProductID"];
                string aProductName = (string)aReader["ProductName"];
                int aSupplierID = (int)aReader["SupplierID"];
                int aCategoryID = (int)aReader["CategoryID"];
                string aQuantityPerUnit = (string)aReader["QuantityPerUnit"];
                double aUnitPrice = (double)(decimal)aReader["UnitPrice"];
                int aUnitsInStock = (short)aReader["UnitsInStock"];
                int aUnitsOnOrder = (short)aReader["UnitsOnOrder"];
                int aReorderLevel = (short)aReader["ReorderLevel"];
                bool isDiscontinued = (bool)aReader["Discontinued"];

                Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                aProductList.Add(aProduct);

            }
            aConnection.Close();
            return aProductList;


        }

        //Gets a list of products filtered by the Unit Price
        public List<Product> GetProductsByUnitPrice(double min, double max)
        {
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();
            List<Product> aProductList = new List<Product>();
            OleDbCommand aCommand = aConnection.CreateCommand();

            BrokenRules theBrokenRules = new BrokenRules();
            BrokenRule aRule = new BrokenRule();
            aRule.RuleName = "Negative Price";
            aRule.RuleDescription = "The Price is not negative";
            theBrokenRules.CheckRule(aRule.RuleName, aRule, !(min < 0));
            theBrokenRules.CheckRule(aRule.RuleName, aRule, !(max < 0));

            aCommand.CommandText = "SELECT ProductID,ProductName,SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE UnitPrice BETWEEN " + min + " AND " + max;
            OleDbDataReader aReader = aCommand.ExecuteReader();

            while (aReader.Read())
            {

                int aProductID = (int)aReader["ProductID"];
                string aProductName = (string)aReader["ProductName"];
                int aSupplierID = (int)aReader["SupplierID"];
                int aCategoryID = (int)aReader["CategoryID"];
                string aQuantityPerUnit = (string)aReader["QuantityPerUnit"];
                double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 9999);
                int aUnitsInStock = (short)aReader["UnitsInStock"];
                int aUnitsOnOrder = (short)aReader["UnitsOnOrder"];
                int aReorderLevel = (short)aReader["ReorderLevel"];
                bool isDiscontinued = (bool)aReader["Discontinued"];

                Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                aProductList.Add(aProduct);


            }
            aConnection.Close();
            return aProductList;

        }

        public void SaveAllProducts()
        {
            Dictionary<int, Product> dictionary = aMap.GetProductDictionary();

            // create the connection object
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();

            // create a command object
            OleDbCommand aCommand = aConnection.CreateCommand();

            // Set the SQL statement
            string aSQL = "";

            foreach (var p in dictionary.Keys)
            {
                int aProductId = dictionary[p].ProductID;
                string aProductName = dictionary[p].ProductName;
                int aSupplierId = dictionary[p].SupplierID;
                int aCategoryId = dictionary[p].CategoryID;
                string aQuantityPerUnit = dictionary[p].QuantityPerUnit;
                double aUnitPrice = dictionary[p].UnitPrice;
                int aUnitsInStock = dictionary[p].UnitsInStock;
                int aUnitsOnOrder = dictionary[p].UnitsOnOrder;
                int aReorderLevel = dictionary[p].ReorderLevel;
                bool isDiscontinued = dictionary[p].Discontinued;


                // If the item is not in the dictionary
                // make a new item and add it to the map
                if (dictionary[p].IsDirty == true)
                {

                    aSQL = "Update Products";
                    aSQL = aSQL + "SET ProductName = " + "'" + aProductName + "', ";
                    aSQL = aSQL + "SupplierId = " + "'" + aSupplierId + "' ";
                    aSQL = aSQL + "CategoryId = " + "'" + aCategoryId + "' ";
                    aSQL = aSQL + "QuantityPerUnit = " + "'" + aQuantityPerUnit + "' ";
                    aSQL = aSQL + "UnitPrice = " + "'" + aUnitPrice + "' ";
                    aSQL = aSQL + "UnitsInStock = " + "'" + aUnitsInStock + "' ";
                    aSQL = aSQL + "UnitsOnOrder = " + "'" + aUnitsOnOrder + "' ";
                    aSQL = aSQL + "ReorderLevel = " + "'" + aReorderLevel + "' ";
                    aSQL = aSQL + "Discontinued = " + "'" + isDiscontinued + "' ";
                    aSQL = aSQL + "WHERE ProductId = " + aProductId;

                    aCommand.CommandText = aSQL;
                    aCommand.ExecuteNonQuery();

                }

            }

            // close the connection
            aConnection.Close();


        }
        public List<Product> GetProductByID(string anID)
        {
            List<Product> aList = new List<Product>();

            aConnection.Open();

                aCommand.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE ProductID = " + anID;
                OleDbDataReader aReader = aCommand.ExecuteReader();

                while (aReader.Read())
                {
                    int aProductID = aReader["ProductID"] as int? ?? -1;
                    string aProductName = aReader["ProductName"] as string ?? String.Empty;
                    int aSupplierID = aReader["SupplierID"] as int? ?? -1;
                    int aCategoryID = aReader["CategoryID"] as int? ?? -1;
                    string aQuantityPerUnit = aReader["QuantityPerUnit"] as string ?? String.Empty;
                    double aUnitPrice = Convert.ToDouble(aReader["UnitPrice"] as decimal? ?? 999999);
                    int aUnitsInStock = aReader["UnitsInStock"] as Int16? ?? 0;
                    int aUnitsOnOrder = aReader["UnitsOnOrder"] as Int16? ?? 0;
                    int aReorderLevel = aReader["ReorderLevel"] as Int16? ?? 0;
                    bool isDiscontinued = aReader["Discontinued"] as bool? ?? true;

                    Product aProduct = new Product(aProductID, aProductName, aSupplierID, aCategoryID, aQuantityPerUnit, aUnitPrice, aUnitsInStock, aUnitsOnOrder, aReorderLevel, isDiscontinued);
                    aList.Add(aProduct);
                }
            aConnection.Close();
            return aList;
        }
    }
}