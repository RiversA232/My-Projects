﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data.Odbc;

namespace Northwind_Asp.Models
{
    public class SupplierGateway
    {
        private SupplierIdentityMap aMap = new SupplierIdentityMap();
        private Supplier aSupplier = null;

        public static string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";
        public static OleDbConnection aConnection = new OleDbConnection(connectionString);
        public OleDbCommand aCommand = aConnection.CreateCommand();

        //Gets a list of all suppliers
        public List<Supplier> GetSuppliers()
        {

            // open the connection
            aConnection.Open();
            List<Supplier> aSupplierList = new List<Supplier>();
            aCommand.CommandText = "SELECT [SupplierId],[CompanyName],[ContactName], ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage FROM Suppliers";
            OleDbDataReader aReader = aCommand.ExecuteReader();
            while (aReader.Read())
            {

                int aSupplierId = (int)aReader["SupplierId"];
                string aCompanyName = (string)aReader["CompanyName"];
                string aContactName = (string)aReader["ContactName"];
                string aContactTitle = (string)aReader["ContactTitle"];
                string aAddress = (string)aReader["Address"];
                string aCity = (string)aReader["City"];
                string aRegion = aReader["Region"] as string ?? String.Empty;
                string aPostalCode = aReader["PostalCode"] as string ?? String.Empty;
                string aCountry = (string)aReader["Country"];
                string aPhone = (string)aReader["Phone"];
                string aFax = aReader["Fax"] as string ?? String.Empty;
                string aHomePage = aReader["HomePage"] as string ?? String.Empty;

                Supplier aSupplier = new Supplier(aSupplierId, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, aFax, aHomePage);
                aSupplierList.Add(aSupplier);
            }

            aConnection.Close();
            return aSupplierList;


        }

        //Gets a list of suppliers filtered by the supplier Id
        public List<Supplier> GetSuppliersById(String theSupplier)
        {
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();
            List<Supplier> aSupplierList = new List<Supplier>();
            OleDbCommand aCommand = aConnection.CreateCommand();
            aCommand.CommandText = "SELECT [SupplierId],[CompanyName],[ContactName], ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage FROM Suppliers WHERE SupplierID = " + theSupplier;
            OleDbDataReader aReader = aCommand.ExecuteReader();
            while (aReader.Read())
            {

                int aSupplierId = (int)aReader["SupplierId"];
                string aCompanyName = (string)aReader["CompanyName"];
                string aContactName = (string)aReader["ContactName"];
                string aContactTitle = (string)aReader["ContactTitle"];
                string aAddress = (string)aReader["Address"];
                string aCity = (string)aReader["City"];
                string aRegion = aReader["Region"] as string ?? String.Empty;
                string aPostalCode = aReader["PostalCode"] as string ?? String.Empty;
                string aCountry = (string)aReader["Country"];
                string aPhone = (string)aReader["Phone"];
                string aFax = aReader["Fax"] as string ?? String.Empty;
                string aHomePage = aReader["HomePage"] as string ?? String.Empty;

                Supplier aSupplier = new Supplier(aSupplierId, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, aPostalCode, aCountry, aPhone, aFax, aHomePage);
                aSupplierList.Add(aSupplier);
            }


            aConnection.Close();
            return aSupplierList;

        }
        public void SaveAllSuppliers()
        {

            Dictionary<int, Supplier> dictionary = aMap.GetSupplierDictionary();

            // create the connection object
            OleDbConnection aConnection = new OleDbConnection();

            // set the connection string
            aConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\aaron\Downloads\Northwind.mdb";

            // open the connection
            aConnection.Open();

            // create a command object
            OleDbCommand aCommand = aConnection.CreateCommand();

            // Set the SQL statement
            string aSQL = "";

            foreach (var p in dictionary.Keys)
            {
                int aSupplierId = dictionary[p].SupplierID;
                string aCompanyName = dictionary[p].CompanyName;
                string aContactName = dictionary[p].ContactName;
                string aContactTitle = dictionary[p].ContactTitle;
                string aAddress = dictionary[p].Address;
                string aCity = dictionary[p].City;
                string aRegion = dictionary[p].Region;
                string aPostalCode = dictionary[p].PostalCode;
                string aCountry = dictionary[p].Country;
                string aPhone = dictionary[p].Phone;
                string aFax = dictionary[p].Fax;
                string aHomePage = dictionary[p].HomePage;


                // If the item is not in the dictionary
                // make a new item and add it to the map
                if (dictionary[p].IsDirty == true)
                {

                    aSQL = "Update Suppliers";
                    aSQL = aSQL + "SET CompanyName = " + "'" + aCompanyName + "', ";
                    aSQL = aSQL + "ContactName = " + "'" + aContactName + "' ";
                    aSQL = aSQL + "ContactTitle = " + "'" + aContactTitle + "' ";
                    aSQL = aSQL + "Address = " + "'" + aAddress + "' ";
                    aSQL = aSQL + "City = " + "'" + aCity + "' ";
                    aSQL = aSQL + "Region = " + "'" + aRegion + "' ";
                    aSQL = aSQL + "PostalCode = " + "'" + aPostalCode + "' ";
                    aSQL = aSQL + "Country = " + "'" + aCountry + "' ";
                    aSQL = aSQL + "Phone = " + "'" + aPhone + "' ";
                    aSQL = aSQL + "Fax = " + "'" + aFax + "' ";
                    aSQL = aSQL + "HomePage = " + "'" + aHomePage + "' ";
                    aSQL = aSQL + "WHERE SupplierId = " + aSupplierId;

                    aCommand.CommandText = aSQL;
                    aCommand.ExecuteNonQuery();

                }

            }

            // close the connection
            aConnection.Close();


        }
    }
}