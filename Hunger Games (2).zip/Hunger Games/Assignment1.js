




for(var x = 1; x < 1001; x++){			//Increases numbers variable by 1 prior to each run.

  if((x%3 == 0) && (x%7 == 0)){
	document.write( x + " Hunger Games" + "<br />"); // If the number is divisible by both, prints out Hunger and Games.
						}					
else if(x%3 == 0){
document.write(x + " Hunger" + "</br>");			//Prints out Hunger if number is divisible by 3.
}

else if(x%7 == 0){
	document.write(x + " Games" + "</br>");		//Prints out  Games if number is divisible by 7.
					}



else{
document.write(x + "</br>");				// Otherwise, print out just the number and a line break.
					}
			}
			
	