﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class ItalianRoast : Beverage
    {
        //making another main beverage and its cost.
        public ItalianRoast()
        {
            this.description = "Nasty.";
        }
        public override double GetCost()
        {
            return 2.00;
        }

        public override string GetDescription()
        {
            return description;
        }

    }
}