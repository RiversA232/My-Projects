﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class Decaf: Beverage
    {

        //One Main type of beverage and its description.

        public Decaf()
        {

            this.description = "Blech!  If you are stupid enough to buy it we will charge you more.";
        }
        public override double GetCost()
        {
            return 2.00;
        }

    }
}