﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class ViennaRoast:Beverage
    {
        //making another main beverage and its cost.
        public ViennaRoast()
        {

            this.description = "Medium-Dark Roasted Coffee.";
        }

        public override double GetCost()
        {
            return 1.00;
        }
    }
}