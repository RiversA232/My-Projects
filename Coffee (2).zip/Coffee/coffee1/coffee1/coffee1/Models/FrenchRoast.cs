﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class FrenchRoast:Beverage
    {
        //making another main beverage and its cost.

        public FrenchRoast()
        {

            this.description = "Dark Roast Coffee.";
        }

        public override double GetCost()
        {
            return 1.00;
        }


    }
}