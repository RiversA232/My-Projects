﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class NutMeg : CondimentDecorator
    {
        //making another addon and its cost.
        Beverage beverage;

        public NutMeg(Beverage aBeverage)
        {
            this.beverage = aBeverage;
        }
        public override string GetDescription()
        {
            return "nutMeg, " + beverage.GetDescription();
        }
        public override double GetCost()
        {
            return (2.00 + beverage.GetCost());
        }
    }
}