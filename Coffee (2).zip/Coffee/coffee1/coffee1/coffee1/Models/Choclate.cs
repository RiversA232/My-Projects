﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace coffee1.Models
{
    public class Chocolate : CondimentDecorator
    {
        // making a beverage addon and its cost.
        Beverage beverage;

        public Chocolate(Beverage aBeverage)
        {
            this.beverage = aBeverage;
        }
        public override string GetDescription()
        {
            return "Chocolate, " + beverage.GetDescription();
        }
        public override double GetCost()
        {
            return (2.00 + beverage.GetCost());
        }
    }
}