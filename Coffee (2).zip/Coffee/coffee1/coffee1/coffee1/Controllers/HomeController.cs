﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using coffee1.Models;
using System.Collections.Specialized;

namespace coffee1.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {            
            return View();
        }

        public ActionResult CheckOut()
        {
            //Get form key/values
            NameValueCollection form = Request.Form;

            if (String.IsNullOrEmpty(form["coffee"]))
            {
                return RedirectToAction("Index");
            }

            string coffee = form["coffee"];                   

            Beverage beverage = new FrenchRoast();

            switch(coffee)
            {
                case "frenchRoast":
                    beverage = new FrenchRoast();
                    break;
                case "viennaRoast":
                    beverage = new ViennaRoast();
                    break;
                case "italianRoast":
                    beverage = new ItalianRoast();
                    break;
                case "mildRoast":
                    beverage = new MildRoast();
                    break;
                case "decaf":
                    beverage = new Decaf();
                    break;
            }

            if (form["addon"] != null)
            {
                string[] addon = form["addon"].Split(',');
                
                foreach (var addons in addon)
                {
                    switch (addons)
                    {
                        case "steamedMilk":
                            beverage = new SteamedMilk(beverage);
                            break;
                        case "honey":
                            beverage = new Honey(beverage);
                            break;
                        case "cinnamon":
                            beverage = new Cinnamon(beverage);
                            break;
                        case "whipCream":
                            beverage = new WhipCream(beverage);
                            break;
                        case "skimMilk":
                            beverage = new SkimMilk(beverage);
                            break;
                        case "mocha":
                            beverage = new Mocha(beverage);
                            break;
                        case "vanilla":
                            beverage = new Vanilla(beverage);
                            break;
                        case "chocolate":
                            beverage = new Chocolate(beverage);
                            break;
                        case "nutMeg":
                            beverage = new NutMeg(beverage);
                            break;
                        case "pumpkinSpice":
                            beverage = new PumpkinSpice(beverage);
                            break;

                        default:
                            break;
                    }
                }
            }

            //sends to view
            ViewBag.description = beverage.GetDescription();
            ViewBag.cost = beverage.GetCost();

        return View();
        }
	}
}